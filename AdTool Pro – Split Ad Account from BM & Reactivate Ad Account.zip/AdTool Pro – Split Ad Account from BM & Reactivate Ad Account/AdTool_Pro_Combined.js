// AD TOOL PRO - CHƯƠNG TRÌNH TỔNG HỢP TÁCH VÀ KÍCH HOẠT TÀI KHOẢN QUẢNG CÁO
// HASoftware - Ads Solution - Auto Version

// Biến thống kê toàn cục
let stats = {
    // Thống kê tách tài khoản
    tachTotalProcessed: 0,
    tachSuccessCount: 0,
    tachFailureCount: 0,
    tachTargetSuccess: 600,
    tachStartTime: null,
    tachActiveRequests: 0,
    tachMaxConcurrentRequests: 200,
    tachIsRunning: false,
    tachCurrentAccounts: [],
    
    // Thống kê kích hoạt tài khoản
    kichHoatTotal: 0,
    kichHoatSuccess: 0,
    kichHoatFailed: 0,
    kichHoatSkipped: 0,
    kichHoatProcessing: 0,
    kichHoatCurrent: 0,
    kichHoatStartTime: null,
    kichHoatIsRunning: false,
    
    // Trạng thái tổng thể
    currentPhase: 'idle', // 'idle', 'tach', 'kichhoat', 'completed'
    isRunning: false,
    failureThreshold: 500,
    
    // Cấu hình mới
    config: {
        enableKichHoat: true, // Có kích hoạt tài khoản sau khi tách không
        failureThresholdToKichHoat: 500, // Số tài khoản thất bại thì chuyển sang kích hoạt
        delayBeforeKichHoat: 300, // Thời gian delay trước khi kích hoạt (giây)
        targetSuccess: 600, // Số TKQC cần tách thành công
        enableDelayBetweenAccounts: false, // Có delay giữa mỗi tài khoản không
        delayBetweenAccounts: 1, // Delay giữa mỗi tài khoản (giây)
        kichHoatBatchSize: 50 // Số tài khoản kích hoạt đồng thời
    }
};

// Tạo giao diện web tổng hợp
function createCombinedWebUI() {
    const style = document.createElement('style');
    style.textContent = `
        .adtool-pro-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 999999;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .adtool-pro-container {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 20px;
            padding: 30px;
            width: 95%;
            max-width: 900px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            color: white;
            position: relative;
            animation: slideIn 0.5s ease-out;
        }
        
        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .adtool-pro-header {
            text-align: center;
            margin-bottom: 25px;
        }
        
        .adtool-pro-title {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .adtool-pro-subtitle {
            font-size: 16px;
            opacity: 0.9;
        }
        
        .adtool-pro-phase-indicator {
            text-align: center;
            margin: 20px 0;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }
        
        .adtool-pro-phase-text {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .adtool-pro-phase-description {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .adtool-pro-sections {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin: 25px 0;
        }
        
        .adtool-pro-section {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }
        
        .adtool-pro-section-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .adtool-pro-progress-container {
            margin: 15px 0;
        }
        
        .adtool-pro-progress-bar {
            width: 100%;
            height: 15px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            overflow: hidden;
            position: relative;
        }
        
        .adtool-pro-progress-fill {
            height: 100%;
            border-radius: 8px;
            transition: width 0.5s ease;
            position: relative;
            overflow: hidden;
        }
        
        .adtool-pro-progress-fill.tach {
            background: linear-gradient(90deg, #ff6b6b, #ee5a24);
        }
        
        .adtool-pro-progress-fill.kichhoat {
            background: linear-gradient(90deg, #4CAF50, #45a049);
        }
        
        .adtool-pro-progress-text {
            text-align: center;
            margin-top: 8px;
            font-size: 14px;
            font-weight: bold;
        }
        
        .adtool-pro-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin: 15px 0;
        }
        
        .adtool-pro-stat-item {
            background: rgba(255, 255, 255, 0.1);
            padding: 12px;
            border-radius: 8px;
            text-align: center;
        }
        
        .adtool-pro-stat-number {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .adtool-pro-stat-label {
            font-size: 11px;
            opacity: 0.8;
        }
        
        .adtool-pro-current {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 10px;
            margin: 15px 0;
        }
        
        .adtool-pro-current-title {
            font-size: 14px;
            margin-bottom: 10px;
            opacity: 0.9;
        }
        
        .adtool-pro-current-accounts {
            max-height: 100px;
            overflow-y: auto;
            font-size: 12px;
            line-height: 1.4;
        }
        
        .adtool-pro-current-account {
            background: rgba(255, 255, 255, 0.1);
            padding: 4px 8px;
            margin: 2px 0;
            border-radius: 4px;
            font-family: monospace;
        }
        
        .adtool-pro-close {
            position: absolute;
            top: 15px;
            right: 20px;
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 20px;
            transition: all 0.3s ease;
        }
        
        .adtool-pro-close:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1);
        }
        
        .adtool-pro-completion {
            text-align: center;
            padding: 25px;
            background: rgba(76, 175, 80, 0.2);
            border-radius: 15px;
            margin-top: 25px;
            display: none;
        }
        
        .adtool-pro-completion.show {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
        }
        
        .adtool-pro-completion-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        
        .adtool-pro-completion-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        
        .adtool-pro-completion-stats {
            font-size: 16px;
            line-height: 1.8;
        }
        
        .adtool-pro-completion-stat-row {
            display: flex;
            justify-content: space-between;
            margin: 8px 0;
            padding: 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
        }
        
        .adtool-pro-timer {
            text-align: center;
            margin: 15px 0;
            font-size: 18px;
            font-weight: bold;
            color: #ffd700;
            text-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
        }
        
        .adtool-pro-controls {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin: 20px 0;
        }
        
        .adtool-pro-btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 120px;
        }
        
        .adtool-pro-btn.start {
            background: linear-gradient(135deg, #4CAF50, #45a049);
            color: white;
        }
        
        .adtool-pro-btn.start:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.4);
        }
        
        .adtool-pro-btn.stop {
            background: linear-gradient(135deg, #f44336, #d32f2f);
            color: white;
        }
        
        .adtool-pro-btn.stop:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(244, 67, 54, 0.4);
        }
        
        .adtool-pro-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none !important;
        }
        
        .adtool-pro-config {
            background: rgba(255, 255, 255, 0.15);
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .adtool-pro-config .adtool-pro-config-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
            color: #ffffff !important;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
        }
        
        .adtool-pro-config-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .adtool-pro-config-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .adtool-pro-config .adtool-pro-config-label,
        .adtool-pro-config label {
            font-size: 14px;
            font-weight: bold;
            color: #ffffff !important;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
            -webkit-text-fill-color: #ffffff !important;
            fill: #ffffff !important;
        }
        
        .adtool-pro-config-input {
            padding: 8px 12px;
            border: none;
            border-radius: 6px;
            background: rgba(255, 255, 255, 0.95);
            color: #333;
            font-size: 14px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }
        
        .adtool-pro-config-input:focus {
            outline: none;
            border-color: #4CAF50;
            box-shadow: 0 0 10px rgba(76, 175, 80, 0.3);
        }
        
        .adtool-pro-config-checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 5px;
        }
        
        .adtool-pro-config-checkbox input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: #4CAF50;
            cursor: pointer;
        }
        
        .adtool-pro-config .adtool-pro-config-checkbox label,
        .adtool-pro-config-checkbox label {
            font-size: 14px;
            cursor: pointer;
            color: #ffffff !important;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
            font-weight: 500;
            -webkit-text-fill-color: #ffffff !important;
            fill: #ffffff !important;
        }
        
        /* Đảm bảo tất cả text trong config đều có màu trắng */
        .adtool-pro-config * {
            color: #ffffff !important;
        }
        
        /* Ngoại lệ cho input fields */
        .adtool-pro-config input[type="number"],
        .adtool-pro-config input[type="text"] {
            color: #333 !important;
            -webkit-text-fill-color: #333 !important;
        }
    `;
    document.head.appendChild(style);

    const modal = document.createElement('div');
    modal.className = 'adtool-pro-modal';
    modal.innerHTML = `
        <div class="adtool-pro-container">
            <button class="adtool-pro-close" id="closeButton">×</button>
            
            <div class="adtool-pro-header">
                <div class="adtool-pro-title">HoangAnhDev - TÁCH & KÍCH HOẠT TÀI KHOẢN QUẢNG CÁO</div>
                <div class="adtool-pro-subtitle">Copyright by HASoftware Ads Solution</div>
                <div class="adtool-pro-subtitle">Liên hệ Telegram Admin nếu gặp sự cố: @HoangAnhDev</div>
            </div>
            
            <div class="adtool-pro-phase-indicator" id="phaseIndicator">
                <div class="adtool-pro-phase-text">⏳ Đang khởi tạo...</div>
                <div class="adtool-pro-phase-description">Chuẩn bị bắt đầu quá trình</div>
            </div>
            
            <div class="adtool-pro-timer" id="timerDisplay" style="display: none;">
                ⏰ Chờ kích hoạt: <span id="timerCountdown">300</span>s
            </div>
            
            <div class="adtool-pro-controls">
                <button class="adtool-pro-btn start" id="startButton">Bắt đầu</button>
                <button class="adtool-pro-btn stop" id="stopButton" disabled>Dừng</button>
            </div>

            <div class="adtool-pro-config">
                <div class="adtool-pro-config-title">⚙️ Cài đặt</div>
                <div class="adtool-pro-config-grid">
                    <div class="adtool-pro-config-item">
                        <label for="tachTargetSuccess">🎯 Số tài khoản thành công cần tách:</label>
                        <input type="number" id="tachTargetSuccess" value="${stats.tachTargetSuccess}" min="1" class="adtool-pro-config-input">
                    </div>
                    <div class="adtool-pro-config-item">
                        <label for="maxConcurrentRequests">⚡ Số tài khoản xử lý đồng thời:</label>
                        <input type="number" id="maxConcurrentRequests" value="${stats.tachMaxConcurrentRequests}" min="1" class="adtool-pro-config-input">
                    </div>
                    <div class="adtool-pro-config-item">
                        <label for="failureThreshold">⚠️ Số lần thất bại tối đa trước khi kích hoạt:</label>
                        <input type="number" id="failureThreshold" value="${stats.failureThreshold}" min="1" class="adtool-pro-config-input">
                    </div>
                    <div class="adtool-pro-config-item">
                        <label for="enableKichHoat">🔓 Bật kích hoạt tài khoản sau khi tách:</label>
                        <div class="adtool-pro-config-checkbox">
                            <input type="checkbox" id="enableKichHoat" ${stats.config.enableKichHoat ? 'checked' : ''}>
                            <label for="enableKichHoat">Bật</label>
                        </div>
                    </div>
                    <div class="adtool-pro-config-item">
                        <label for="delayBeforeKichHoat">⏰ Thời gian delay trước khi kích hoạt (giây):</label>
                        <input type="number" id="delayBeforeKichHoat" value="${stats.config.delayBeforeKichHoat}" min="0" class="adtool-pro-config-input">
                    </div>
                    <div class="adtool-pro-config-item">
                        <label for="enableDelayBetweenAccounts">⏱️ Bật delay giữa các tài khoản:</label>
                        <div class="adtool-pro-config-checkbox">
                            <input type="checkbox" id="enableDelayBetweenAccounts" ${stats.config.enableDelayBetweenAccounts ? 'checked' : ''}>
                            <label for="enableDelayBetweenAccounts">Bật</label>
                        </div>
                    </div>
                    <div class="adtool-pro-config-item">
                        <label for="delayBetweenAccounts">⏱️ Thời gian delay giữa các tài khoản (giây):</label>
                        <input type="number" id="delayBetweenAccounts" value="${stats.config.delayBetweenAccounts}" min="0" class="adtool-pro-config-input">
                    </div>
                    <div class="adtool-pro-config-item">
                        <label for="kichHoatBatchSize">🚀 Số tài khoản kích hoạt đồng thời:</label>
                        <input type="number" id="kichHoatBatchSize" value="50" min="10" max="200" class="adtool-pro-config-input">
                    </div>
                </div>
            </div>
            
            <div class="adtool-pro-sections">
                <div class="adtool-pro-section">
                    <div class="adtool-pro-section-title">TÁCH TÀI KHOẢN QUẢNG CÁO</div>
                    
                    <div class="adtool-pro-progress-container">
                        <div class="adtool-pro-progress-bar">
                            <div class="adtool-pro-progress-fill tach" id="tachProgressFill" style="width: 0%"></div>
                        </div>
                        <div class="adtool-pro-progress-text" id="tachProgressText">0% (0/${stats.tachTargetSuccess})</div>
                    </div>
                    
                    <div class="adtool-pro-stats">
                        <div class="adtool-pro-stat-item">
                            <div class="adtool-pro-stat-number" id="tachSuccessCount">0</div>
                            <div class="adtool-pro-stat-label">✅ Thành công</div>
                        </div>
                        <div class="adtool-pro-stat-item">
                            <div class="adtool-pro-stat-number" id="tachFailureCount">0</div>
                            <div class="adtool-pro-stat-label">❌ Thất bại</div>
                        </div>
                        <div class="adtool-pro-stat-item">
                            <div class="adtool-pro-stat-number" id="tachTotalProcessed">0</div>
                            <div class="adtool-pro-stat-label">⏱️ Đã xử lý</div>
                        </div>
                        <div class="adtool-pro-stat-item">
                            <div class="adtool-pro-stat-number" id="tachActiveRequests">0</div>
                            <div class="adtool-pro-stat-label">🔄 Đang xử lý</div>
                        </div>
                    </div>
                    
                    <div class="adtool-pro-current">
                        <div class="adtool-pro-current-title">⚡ Đang tách:</div>
                        <div class="adtool-pro-current-accounts" id="tachCurrentAccounts">
                            <div class="adtool-pro-current-account">Chờ bắt đầu...</div>
                        </div>
                    </div>
                </div>
                
                <div class="adtool-pro-section">
                    <div class="adtool-pro-section-title">REACTIVE TÀI KHOẢN</div>
                    
                    <div class="adtool-pro-progress-container">
                        <div class="adtool-pro-progress-bar">
                            <div class="adtool-pro-progress-fill kichhoat" id="kichHoatProgressFill" style="width: 0%"></div>
                        </div>
                        <div class="adtool-pro-progress-text" id="kichHoatProgressText">0% (0/0)</div>
                    </div>
                    
                    <div class="adtool-pro-stats">
                        <div class="adtool-pro-stat-item">
                            <div class="adtool-pro-stat-number" id="kichHoatSuccess">0</div>
                            <div class="adtool-pro-stat-label">✅ Thành công</div>
                        </div>
                        <div class="adtool-pro-stat-item">
                            <div class="adtool-pro-stat-number" id="kichHoatFailed">0</div>
                            <div class="adtool-pro-stat-label">❌ Thất bại</div>
                        </div>
                        <div class="adtool-pro-stat-item">
                            <div class="adtool-pro-stat-number" id="kichHoatSkipped">0</div>
                            <div class="adtool-pro-stat-label">⏭️ Bỏ qua</div>
                        </div>
                        <div class="adtool-pro-stat-item">
                            <div class="adtool-pro-stat-number" id="kichHoatCurrent">0</div>
                            <div class="adtool-pro-stat-label">📊 Đang xử lý</div>
                        </div>
                    </div>
                    
                    <div class="adtool-pro-current">
                        <div class="adtool-pro-current-title">⚡ Đang kích hoạt:</div>
                        <div class="adtool-pro-current-accounts" id="kichHoatCurrentAccounts">
                            <div class="adtool-pro-current-account">Chờ bắt đầu...</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="adtool-pro-completion" id="completionSection">
                <div class="adtool-pro-completion-icon">🎉</div>
                <div class="adtool-pro-completion-title">HOÀN THÀNH TOÀN BỘ QUÁ TRÌNH!</div>
                <div class="adtool-pro-completion-stats" id="completionStats"></div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Thêm event listeners cho các nút
    addEventListeners();
    
    return modal;
}

// Hàm thêm event listeners
function addEventListeners() {
    try {
        console.log('🔧 Đang thêm event listeners...');
        
        const startButton = document.getElementById('startButton');
        const stopButton = document.getElementById('stopButton');
        const closeButton = document.getElementById('closeButton');
        
        console.log('🔍 Tìm thấy các nút:', {
            startButton: !!startButton,
            stopButton: !!stopButton,
            closeButton: !!closeButton
        });
        
        if (startButton) {
            startButton.addEventListener('click', function(e) {
                e.preventDefault();
                console.log('🚀 Bấm nút Start - Bắt đầu quá trình');
                mainCombinedProcess();
            });
            console.log('✅ Đã thêm event listener cho nút Start');
        }
        
        if (stopButton) {
            stopButton.addEventListener('click', function(e) {
                e.preventDefault();
                console.log('🛑 Bấm nút Stop - Dừng quá trình');
                stopAdToolPro();
            });
            console.log('✅ Đã thêm event listener cho nút Stop');
        }
        
        if (closeButton) {
            closeButton.addEventListener('click', function(e) {
                e.preventDefault();
                console.log('❌ Bấm nút Close - Đóng giao diện');
                closeCombinedWebUI();
            });
            console.log('✅ Đã thêm event listener cho nút Close');
        }
        
        console.log('✅ Đã thêm event listeners thành công');
    } catch (error) {
        console.error('❌ Lỗi khi thêm event listeners:', error);
    }
}

// Cập nhật giao diện tổng hợp
function updateCombinedWebUI() {
    // Cập nhật phần tách tài khoản
    const tachProgressFill = document.getElementById('tachProgressFill');
    const tachProgressText = document.getElementById('tachProgressText');
    const tachSuccessCount = document.getElementById('tachSuccessCount');
    const tachFailureCount = document.getElementById('tachFailureCount');
    const tachTotalProcessed = document.getElementById('tachTotalProcessed');
    const tachActiveRequests = document.getElementById('tachActiveRequests');
    const tachCurrentAccounts = document.getElementById('tachCurrentAccounts');
    
    if (tachProgressFill && tachProgressText) {
        const percentage = Math.round((stats.tachSuccessCount / stats.config.targetSuccess) * 100);
        tachProgressFill.style.width = percentage + '%';
        tachProgressText.textContent = `${percentage}% (${stats.tachSuccessCount}/${stats.config.targetSuccess})`;
    }
    
    if (tachSuccessCount) tachSuccessCount.textContent = stats.tachSuccessCount;
    if (tachFailureCount) tachFailureCount.textContent = stats.tachFailureCount;
    if (tachTotalProcessed) tachTotalProcessed.textContent = stats.tachTotalProcessed;
    if (tachActiveRequests) tachActiveRequests.textContent = stats.tachActiveRequests;
    
    if (tachCurrentAccounts) {
        if (stats.tachCurrentAccounts.length > 0) {
            tachCurrentAccounts.innerHTML = stats.tachCurrentAccounts
                .slice(0, 8)
                .map(account => `<div class="adtool-pro-current-account">${account}</div>`)
                .join('');
            
            if (stats.tachCurrentAccounts.length > 8) {
                tachCurrentAccounts.innerHTML += `<div class="adtool-pro-current-account">... và ${stats.tachCurrentAccounts.length - 8} tài khoản khác</div>`;
            }
        } else {
            tachCurrentAccounts.innerHTML = '<div class="adtool-pro-current-account">Chờ bắt đầu...</div>';
        }
    }
    
    // Cập nhật phần kích hoạt tài khoản
    const kichHoatProgressFill = document.getElementById('kichHoatProgressFill');
    const kichHoatProgressText = document.getElementById('kichHoatProgressText');
    const kichHoatSuccess = document.getElementById('kichHoatSuccess');
    const kichHoatFailed = document.getElementById('kichHoatFailed');
    const kichHoatSkipped = document.getElementById('kichHoatSkipped');
    const kichHoatCurrent = document.getElementById('kichHoatCurrent');
    const kichHoatCurrentAccounts = document.getElementById('kichHoatCurrentAccounts');
    
    if (kichHoatProgressFill && kichHoatProgressText) {
        // Tính số tài khoản đã xử lý (thành công + thất bại)
        const kichHoatProcessed = stats.kichHoatSuccess + stats.kichHoatFailed;
        const percentage = stats.kichHoatTotal > 0 ? Math.round((kichHoatProcessed / stats.kichHoatTotal) * 100) : 0;
        kichHoatProgressFill.style.width = percentage + '%';
        kichHoatProgressText.textContent = `${percentage}% (${kichHoatProcessed}/${stats.kichHoatTotal})`;
    }
    
    if (kichHoatSuccess) kichHoatSuccess.textContent = stats.kichHoatSuccess;
    if (kichHoatFailed) kichHoatFailed.textContent = stats.kichHoatFailed;
    if (kichHoatSkipped) kichHoatSkipped.textContent = stats.kichHoatSkipped;
    if (kichHoatCurrent) kichHoatCurrent.textContent = stats.kichHoatCurrent;
    
    if (kichHoatCurrentAccounts) {
        if (stats.kichHoatIsRunning) {
            kichHoatCurrentAccounts.innerHTML = '<div class="adtool-pro-current-account">Đang xử lý tài khoản...</div>';
        } else if (stats.kichHoatSuccess > 0 || stats.kichHoatFailed > 0) {
            kichHoatCurrentAccounts.innerHTML = '<div class="adtool-pro-current-account">Đã hoàn thành xử lý</div>';
        } else {
            kichHoatCurrentAccounts.innerHTML = '<div class="adtool-pro-current-account">Chờ bắt đầu...</div>';
        }
    }
}

// Cập nhật chỉ báo pha
function updatePhaseIndicator(phase, description) {
    const phaseIndicator = document.getElementById('phaseIndicator');
    const phaseText = document.getElementById('phaseIndicator').querySelector('.adtool-pro-phase-text');
    const phaseDescription = document.getElementById('phaseIndicator').querySelector('.adtool-pro-phase-description');
    
    if (phaseIndicator && phaseText && phaseDescription) {
        stats.currentPhase = phase;
        
        switch(phase) {
            case 'tach':
                phaseText.textContent = '⛏ ĐANG TÁCH TÀI KHOẢN';
                phaseDescription.textContent = description || 'Đang tách tài khoản quảng cáo từ Business Manager';
                break;
            case 'kichhoat':
                phaseText.textContent = '🔓 ĐANG KÍCH HOẠT TÀI KHOẢN';
                phaseDescription.textContent = description || 'Đang kích hoạt lại các tài khoản đã tách';
                break;
            case 'completed':
                phaseText.textContent = '✅ HOÀN THÀNH';
                phaseDescription.textContent = description || 'Tất cả quá trình đã hoàn tất';
                break;
            default:
                phaseText.textContent = '⏳ ĐANG KHỞI TẠO';
                phaseDescription.textContent = description || 'Chuẩn bị bắt đầu quá trình';
        }
    }
}

// Hiển thị timer đếm ngược
function showTimer(seconds) {
    const timerDisplay = document.getElementById('timerDisplay');
    const timerCountdown = document.getElementById('timerCountdown');
    
    if (timerDisplay && timerCountdown) {
        timerDisplay.style.display = 'block';
        timerCountdown.textContent = seconds;
        
        const countdown = setInterval(() => {
            seconds--;
            timerCountdown.textContent = seconds;
            
            if (seconds <= 0) {
                clearInterval(countdown);
                timerDisplay.style.display = 'none';
            }
        }, 1000);
    }
}

// Hiển thị thông báo hoàn thành
function showCompletionCombinedWebUI() {
    const completionSection = document.getElementById('completionSection');
    const completionStats = document.getElementById('completionStats');
    
    if (completionSection && completionStats) {
        const tachEndTime = new Date();
        const tachDuration = Math.round((tachEndTime - stats.tachStartTime) / 1000);
        const tachSuccessRate = stats.tachTotalProcessed > 0 ? Math.round((stats.tachSuccessCount / stats.tachTotalProcessed) * 100) : 0;
        
        const kichHoatEndTime = new Date();
        const kichHoatDuration = stats.kichHoatStartTime ? Math.round((kichHoatEndTime - stats.kichHoatStartTime) / 1000) : 0;
        
        // Tính tỷ lệ thành công cho kích hoạt
        const kichHoatProcessed = stats.kichHoatSuccess + stats.kichHoatFailed;
        const kichHoatSuccessRate = kichHoatProcessed > 0 ? Math.round((stats.kichHoatSuccess / kichHoatProcessed) * 100) : 0;
        
        completionStats.innerHTML = `
            <div class="adtool-pro-completion-stat-row">
                <span>🔧 TÁCH TÀI KHOẢN:</span>
                <span><strong>${stats.tachSuccessCount}/${stats.config.targetSuccess} thành công</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>📊 Tổng xử lý:</span>
                <span><strong>${stats.tachTotalProcessed}</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>✅ Thành công:</span>
                <span><strong>${stats.tachSuccessCount}</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>❌ Thất bại:</span>
                <span><strong>${stats.tachFailureCount}</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>📈 Tỷ lệ thành công:</span>
                <span><strong>${tachSuccessRate}%</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>⏱️ Thời gian tách:</span>
                <span><strong>${tachDuration} giây</strong></span>
            </div>
            
            <div style="margin: 20px 0; border-top: 1px solid rgba(255,255,255,0.3); padding-top: 20px;"></div>
            
            <div class="adtool-pro-completion-stat-row">
                <span>🔓 KÍCH HOẠT TÀI KHOẢN:</span>
                <span><strong>${stats.kichHoatSuccess}/${kichHoatProcessed} thành công</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>📊 Tổng tài khoản:</span>
                <span><strong>${stats.kichHoatTotal}</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>✅ Thành công:</span>
                <span><strong>${stats.kichHoatSuccess}</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>❌ Thất bại:</span>
                <span><strong>${stats.kichHoatFailed}</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>⏭️ Bỏ qua:</span>
                <span><strong>${stats.kichHoatSkipped}</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>📈 Tỷ lệ thành công:</span>
                <span><strong>${kichHoatSuccessRate}%</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>⏱️ Thời gian kích hoạt:</span>
                <span><strong>${kichHoatDuration} giây</strong></span>
            </div>
            
            <div style="margin: 20px 0; border-top: 1px solid rgba(255,255,255,0.3); padding-top: 20px;"></div>
            
            <div class="adtool-pro-completion-stat-row">
                <span>🎯 TỔNG KẾT:</span>
                <span><strong>${stats.tachSuccessCount + stats.kichHoatSuccess} tài khoản hoàn tất</strong></span>
            </div>
            <div class="adtool-pro-completion-stat-row">
                <span>⚡ Tổng thời gian:</span>
                <span><strong>${tachDuration + kichHoatDuration} giây</strong></span>
            </div>
        `;
        
        completionSection.classList.add('show');
    }
}

// Đóng giao diện
function closeCombinedWebUI() {
    const modal = document.querySelector('.adtool-pro-modal');
    if (modal) {
        modal.style.animation = 'slideOut 0.3s ease-in forwards';
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

// Thêm CSS cho animation đóng
const closeStyle = document.createElement('style');
closeStyle.textContent = `
    @keyframes slideOut {
        from { transform: translateY(0); opacity: 1; }
        to { transform: translateY(-50px); opacity: 0; }
    }
`;
document.head.appendChild(closeStyle); 

// ==================== PHẦN TÁCH TÀI KHOẢN ====================

async function getReadOnlyAccountIds() {
    const request = await fetch(`https://graph.facebook.com/v17.0/${require('BusinessUnifiedNavigationContext').businessID}/owned_ad_accounts?access_token=${require('WebApiApplication').getAccessToken()}&__activeScenarioIDs=%5B%5D&__activeScenarios=%5B%5D&__interactionsMetadata=%5B%5D&_reqName=object%3Abusiness%2Fowned_ad_accounts&_reqSrc=BusinessConnectedOwnedAdAccountsStore.brands&date_format=U&fields=%5B%22id%22%2C%22name%22%2C%22account_id%22%2C%22account_status%22%2C%22business%22%2C%22created_time%22%2C%22currency%22%2C%22timezone_name%22%2C%22end_advertiser%22%2C%22end_advertiser_name%22%2C%22invoicing_emails%22%2C%22is_disabled_umbrella%22%2C%22last_spend_time%22%2C%22funding_source%22%2C%22can_be_blocked_from_pixel_sharing%22%2C%22disable_reason%22%2C%22bill_to_org.fields(legal_entity_name)%22%2C%22onbehalf_requests.fields(receiving_business.fields(name)%2Cstatus)%22%5D&filtering=%5B%7B%22field%22%3A%22account_status%22%2C%22operator%22%3A%22NOT_EQUAL%22%2C%22value%22%3A%226%22%7D%5D&limit=10000&locale=vi_VN&method=get&pretty=0&sort=name_ascending&suppress_http_code=1&xref=f41c4c0b703bc`, 
    {
        "headers": {
            "content-type": "application/x-www-form-urlencoded"
        },
        "method": "GET",
        "mode": "cors",
        "credentials": "include"
    });

    const text = await request.text();
    const data = JSON.parse(text).data;

    // Lọc các tài khoản có "Read-Only" trong tên
    const readOnlyIds = data
        .filter(item => item.name && item.name.includes("Read-Only"))
        .map(item => item.account_id);

    return readOnlyIds;
}

async function addpermission(adAccountId) {
    const rawJson = {
        input: {
            business_id: require("BusinessUnifiedNavigationContext").businessID,
            payment_legacy_account_id: adAccountId,
            actor_id: require("CurrentUserInitialData").USER_ID,
            client_mutation_id: "2"
        }
    };
    const encodedJson = encodeURIComponent(JSON.stringify(rawJson));
    const url = `https://graph.facebook.com/graphql?method=post&locale=en_US&pretty=false&format=json&fb_api_req_friendly_name=useBillingSelfGrantManageAdAccountMutation&doc_id=6600383160000030&fb_api_caller_class=RelayModern&server_timestamps=true&variables=${encodedJson}&access_token=${require("WebApiApplication").getAccessToken()}`;
    try {
        const response = await fetch(url, {
            method: 'GET',
            credentials: 'include'
        });
        const data = await response.json();

        const billingWritePermission = data?.data?.grant_manage_ad_account?.ad_account?.viewer_permissions?.billing_write;

        if (billingWritePermission) {
            return { status: true, error: null };
        } else {
            return { status: false, error: data };
        }
    } catch (err) {
        return { status: false, error: err };
    }
}

async function CloseAdAccount(adAccountId) {
    const StringPost = `jazoest=25524&fb_dtsg=${require("DTSGInitData").token}&account_id=${adAccountId}&__usid=6-Tskqo1h1o56glr%3APskqo1h16o00sk%3A0-Askqn631d2395g-RV%3D6%3AF%3D&__aaid=0&__bid=${require("BusinessUnifiedNavigationContext").businessID}&__user=${require("CurrentUserInitialData").USER_ID}&__a=1&__req=y&__hs=19998.BP%3Abrands_pkg.2.0..0.0&dpr=1&__ccg=EXCELLENT&__rev=1016990685&__s=axc5os%3A4n4eqp%3A948yz8&__hsi=7421228722412779754&__dyn=7xeUmxa2C5rgydwCwRyUbFp4Unxim2q1Dxuq3mq1FxebzA3miidBxa7EiwnobES2S2q1Ex21FxG9y8Gdz8hw9-3a4EuCwQwCxq0yFE4WqbwQzobVqxN0Cmu3mbx-261UxO4UkK2y1gwBwXwEw-G2mcwuE2Bz84a9DxW10wywWjxCU5-u2C2l0Fg2uwEwiUmwoErorx2aK2a4p8aHwzzXx-ewjovCxeq4o884O1fwwxefzo5G4E5yeDyU52dwyw-z8c8-5aDwQwKG13y86qbxa4o-2-qaUK2e0UFU2RwrU6CiU9E4KeCK2q5UpwDwjouxK2i2y1sDw4kwtU5K2G0BE&__csr=&lsd=h2GQa8HPsn-MsvTtASY4gX&__spin_r=1016990685&__spin_b=trunk&__spin_t=1727889460&__jssesw=1`;
    const url = `https://business.facebook.com/ads/ajax/account_close`;

    try {
        const response = await fetch(url, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: StringPost
        });
        let text = await response.text();
        if (text.startsWith('for (;;);')) {
            text = text.slice('for (;;);'.length);
        }
        const data = JSON.parse(text);

        if (Array.isArray(data?.payload) && data.payload.length === 0) {
            return { status: true, error: null };
        } else {
            return { status: false, error: data };
        }
    } catch (err) {
        return { status: false, error: err };
    }
}

// Hàm xử lý một tài khoản (song song)
async function processSingleAccount(accountId, index) {
    stats.tachActiveRequests++;
    
    // Thêm tài khoản vào danh sách đang xử lý
    const accountDisplay = `${accountId} (${index} - Thành công: ${stats.tachSuccessCount}/${stats.config.targetSuccess})`;
    stats.tachCurrentAccounts.push(accountDisplay);
    updateCombinedWebUI();
    
    try {
        console.log(`🔄 [${index}] Bắt đầu xử lý ${accountId}...`);
        
        const addpermissionResult = await addpermission(accountId);
        if (addpermissionResult.status) {
            console.log(`✅ [${index}] ADD People ${accountId}: SUCCESS`);
            const TachAds = await CloseAdAccount(accountId);
            if (TachAds.status) {
                console.log(`✅ [${index}] TÁCH ${accountId}: SUCCESS`);
                stats.tachSuccessCount++;
                
                // Kiểm tra nếu đã đạt đủ số tài khoản thành công
                if (stats.tachSuccessCount >= stats.config.targetSuccess) {
                    stats.tachTotalProcessed++;
                    updateCombinedWebUI();
                    return { completed: true, reason: 'target_reached' };
                }
            } else {
                console.error(`❌ [${index}] TÁCH ${accountId} error:`, TachAds.error);
                stats.tachFailureCount++;
                
                // Kiểm tra nếu số lần thất bại vượt quá ngưỡng
                if (stats.tachFailureCount >= stats.config.failureThresholdToKichHoat) {
                    stats.tachTotalProcessed++;
                    updateCombinedWebUI();
                    return { completed: true, reason: 'failure_threshold' };
                }
            }
        } else {
            console.error(`❌ [${index}] ADD People ${accountId} error:`, addpermissionResult.error);
            stats.tachFailureCount++;
            
            // Kiểm tra nếu số lần thất bại vượt quá ngưỡng
            if (stats.tachFailureCount >= stats.config.failureThresholdToKichHoat) {
                stats.tachTotalProcessed++;
                updateCombinedWebUI();
                return { completed: true, reason: 'failure_threshold' };
            }
        }
        
        stats.tachTotalProcessed++;
        
        // Delay giữa các tài khoản nếu được bật
        if (stats.config.enableDelayBetweenAccounts && stats.config.delayBetweenAccounts > 0) {
            await new Promise(resolve => setTimeout(resolve, stats.config.delayBetweenAccounts * 1000));
        }
        
    } catch (error) {
        console.error(`❌ [${index}] Lỗi xử lý ${accountId}:`, error);
        stats.tachFailureCount++;
        stats.tachTotalProcessed++;
        
        // Kiểm tra nếu số lần thất bại vượt quá ngưỡng
        if (stats.tachFailureCount >= stats.config.failureThresholdToKichHoat) {
            updateCombinedWebUI();
            return { completed: true, reason: 'failure_threshold' };
        }
    } finally {
        // Xóa tài khoản khỏi danh sách đang xử lý
        const accountIndex = stats.tachCurrentAccounts.indexOf(accountDisplay);
        if (accountIndex > -1) {
            stats.tachCurrentAccounts.splice(accountIndex, 1);
        }
        stats.tachActiveRequests--;
        updateCombinedWebUI();
    }
    
    return { completed: false, reason: null };
}

async function processAccountsParallel(accountIds) {
    console.log(`🚀 Bắt đầu xử lý SONG SONG ${accountIds.length} tài khoản (Cần thêm ${stats.tachTargetSuccess - stats.tachSuccessCount} tài khoản thành công)`);
    console.log(`⚡ Xử lý đồng thời tối đa: ${stats.tachMaxConcurrentRequests} tài khoản`);
    
    // Tạo tất cả promises cùng lúc
    const promises = accountIds.map((accountId, index) => {
        const globalIndex = stats.tachTotalProcessed + index + 1;
        return processSingleAccount(accountId, globalIndex);
    });
    
    // Chờ tất cả hoàn thành
    const results = await Promise.all(promises);
    
    // Kiểm tra kết quả
    for (const result of results) {
        if (result.completed) {
            return result;
        }
    }
    
    return { completed: false, reason: null };
}

async function startTachProcess() {
    stats.tachStartTime = new Date();
    stats.tachIsRunning = true;
    stats.currentPhase = 'tach';
    
    updatePhaseIndicator('tach', 'Đang tách tài khoản quảng cáo từ Business Manager');
    
    console.log('🎯 BẮT ĐẦU TÁCH TÀI KHOẢN QUẢNG CÁO (SONG SONG - GIỚI HẠN THEO THÀNH CÔNG)');
    console.log(`�� Mục tiêu: ${stats.config.targetSuccess} tài khoản THÀNH CÔNG`);
    console.log(`⚡ Chế độ: Xử lý đồng thời tối đa ${stats.tachMaxConcurrentRequests} tài khoản`);
    console.log(`⏰ Thời gian bắt đầu: ${stats.tachStartTime.toLocaleString()}`);
    console.log('=====================================\n');
    
    while (stats.tachIsRunning && stats.isRunning) {
        const accountIds = await getReadOnlyAccountIds();
        if (accountIds.length > 0) {
            const result = await processAccountsParallel(accountIds);
            if (result.completed) {
                console.log(`🎉 Dừng quá trình tách: ${result.reason}`);
                if (result.reason === 'target_reached') {
                    console.log('✅ Đã đạt đủ số tài khoản thành công!');
                } else if (result.reason === 'failure_threshold') {
                    console.log('⚠️ Số lần thất bại vượt quá ngưỡng! Chuyển sang kích hoạt tài khoản.');
                }
                break;
            }
        } else {
            console.log("Không tìm thấy tài khoản Read-Only nào.");
            stats.tachCurrentAccounts = ["Không tìm thấy tài khoản Read-Only"];
            updateCombinedWebUI();
        }
        await new Promise(resolve => setTimeout(resolve, 5000)); // Đợi 5 giây
    }
    
    stats.tachIsRunning = false;
    return stats.tachSuccessCount;
} 

// ==================== PHẦN KÍCH HOẠT TÀI KHOẢN ====================

// Lấy access token và các thông tin cần thiết
function getRequiredData() {
    let access_token;
    let fb_dtsg2 = require("DTSGInitialData").token || document.querySelector('[name="fb_dtsg"]').value;
    let uid = require("CurrentUserInitialData").USER_ID || document.cookie.match(/c_user=(\d+)/)[1];

    try {
        access_token = require("WebApiApplication").getAccessToken();
    } catch (error) { }

    if (access_token === undefined || access_token === '') {
        console.error('Lỗi: Không thể lấy access token. Vui lòng đảm bảo đã đăng nhập Facebook và thử lại');
        return null;
    }

    return { access_token, fb_dtsg2, uid };
}

async function getBusinesses2(access_token) {
    const ver = "v14.0";
    const response = await fetch(
        `https://graph.facebook.com/${ver}/me?fields=id,name,adaccounts.limit(1000){account_status,created_time,owner,name}&access_token=${access_token}`,
        {
            method: 'GET',
            credentials: 'include',
        }
    );
    const json = await response.json();
    return json;
}

async function action2(businessID, index, total, accountName, access_token, fb_dtsg2, uid) {
    const url = `https://business.facebook.com/api/graphql/?_callFlowletID=0&_triggerFlowletID=78266`;
  
    try {
        console.log(`🔄 [${index + 1}/${total}] Gửi request kích hoạt act_${businessID}`);
        
        const response = await fetch(url, {
            method: 'POST',
            body: `av=${uid}&__usid=6-Tskqef5m5416h%3APskqefx164ljb2%3A1-Askqea7pchdsm-RV%3D6%3AF%3D&__aaid=${businessID}&__user=${uid}&__a=1&__req=88&__hs=19998.BP%3Aads_manager_pkg.2.0..0.0&dpr=1&__ccg=UNKNOWN&__rev=1016987598&__s=z2tt9o%3Alkfjeh%3A8vmk3x&__hsi=7421175297378821716&__dyn=7AgSXgWGgWEjgDBxmSudg9omoiyoK6FVpkihG5Xx2m2q3K2KmeGqKi5axeqaScCCG225pojACjyocuF98SmqnK7GzUuwDxq4EOezoK26UKbC-mdwTxOESegGbwgEmK9y8Gdz8hyUuxqt1eiUO4EgCyku4oS4EWfGUhwyg9p44889EScxyu6UGq13yHGmmUTxJe9LgbeWG9DDl0zlBwyzp8KUV2U8oK1IxO4VAcKmieyp8BlBUK2O4UOi3Kdx29wgojKbUO1Wxu4GBwkEuz478shECumbz8KiewwBK68eF9UhK1vDyojyUix92UtgKi3a6Ex0RyQcKazQ3G5EbpEtzA6Sax248GUgz98hAy8tKU-4U-UG7F8a898vhojCx6EO489UW5ohwZAxK4U-dwMxeayEiwAgCmq6UCQubxu3ydDxG8wRyK4UoLzokGp5yrz8C9wFjQfyoaoym9yA4Ekx24oK4Ehzawwy9pEHyU8Uiwg8KawrVV-i782bByUeoQwox3UO364GJe2q3KfzFLxny9onxDwBwXx67HxtBxO64uWg-26q2au5onADzEHDUyEkjByo4a9AwHxq5kiUarx5e8wAAAVQEhyeucyEy3aQ48B5wPDBw&__csr=&__comet_req=25&fb_dtsg=${fb_dtsg2}&jazoest=25353&lsd=_dtDtv84z9OIgGn5IXOdW2&__spin_r=1016987598&__spin_b=trunk&__spin_t=1727877021&__jssesw=1&qpl_active_flow_ids=270206671%2C270211726%2C270213183&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=useBillingReactivateAdAccountMutation&variables=%7B%22input%22%3A%7B%22billable_account_payment_legacy_account_id%22%3A%22${businessID}%22%2C%22logging_data%22%3A%7B%22logging_counter%22%3A22%2C%22logging_id%22%3A%22559255213%22%7D%2C%22upl_logging_data%22%3A%7B%22context%22%3A%22billingaccountinfo%22%2C%22entry_point%22%3A%22power_editor%22%2C%22external_flow_id%22%3A%22%22%2C%22target_name%22%3A%22BillingReactivateAdAccountMutation%22%2C%22user_session_id%22%3A%22upl_1727876994352_7d1de259-07b1-4107-8ddf-e616f492eac6%22%2C%22wizard_config_name%22%3A%22REACTIVATE_AD_ACCOUNT%22%2C%22wizard_name%22%3A%22REACTIVATE_AD_ACCOUNT%22%2C%22wizard_screen_name%22%3A%22reactivate_ad_account_state_display%22%2C%22wizard_session_id%22%3A%22upl_wizard_1727876994352_902bd8bd-c035-4924-9f33-94b00c9a5b20%22%2C%22wizard_state_name%22%3A%22reactivate_ad_account_state_display%22%7D%2C%22actor_id%22%3A%22${uid}%22%2C%22client_mutation_id%22%3A%227%22%7D%7D&server_timestamps=true&doc_id=9984888131552276&fb_api_analytics_tags=%5B%22qpl_active_flow_ids%3D270206671%2C270211726%2C270213183%22%5D`,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
        
        const responseText = await response.text();
        console.log(`📄 [${index + 1}/${total}] Response cho act_${businessID}: ${responseText.substring(0, 200)}...`);
        
        if (responseText.includes('status":"ADMARKET_ACCOUNT_STATUS_ACTIVE')) {
            stats.kichHoatSuccess++;
            console.log(`${index + 1}/${total} act_${businessID} | -> ✅ Thành công`);
        } else {
            stats.kichHoatFailed++;
            console.log(`${index + 1}/${total} act_${businessID} | -> ❌ Thất bại: ${responseText.substring(0, 100)}`);
        }
        
        // Giảm số lượng đang xử lý sau khi hoàn thành
        stats.kichHoatProcessing--;
        
    } catch (error) {
        stats.kichHoatFailed++;
        stats.kichHoatProcessing--;
        console.log(`${index + 1}/${total} act_${businessID} | -> ❌ Lỗi: ${error.message}`);
    }
}

// Thay đổi logic kích hoạt từ tuần tự sang song song
async function action1(index, arr, access_token, fb_dtsg2, uid) {
    const total = arr.data.adaccounts.data.length;
    stats.kichHoatTotal = total;
    stats.kichHoatCurrent = index;
    
    if (index >= total) {
        console.log(`🎉 Hoàn thành kích hoạt! Thành công: ${stats.kichHoatSuccess}/${stats.kichHoatTotal}`);
        stats.kichHoatIsRunning = false;
        return;
    }
    
    // Kiểm tra nếu đã dừng
    if (!stats.isRunning) {
        console.log('🛑 Đã dừng chương trình kích hoạt');
        stats.kichHoatIsRunning = false;
        return;
    }
    
    try {
        const data = arr.data.adaccounts.data[index];
        const businessID = data.id.replace("act_", "");
        
        if (data.account_status === 100 || data.account_status === 101) {
            stats.kichHoatProcessing++;
            console.log(`🔄 [${index + 1}/${total}] Bắt đầu kích hoạt act_${businessID}`);
            
            // Kiểm tra lại trạng thái dừng trước khi gọi action2
            if (!stats.isRunning) {
                console.log('🛑 Đã dừng chương trình kích hoạt');
                stats.kichHoatIsRunning = false;
                return;
            }
            
            // Gọi action2 không await để xử lý song song
            action2(businessID, index, total, data.name, access_token, fb_dtsg2, uid);
            
        } else {
            stats.kichHoatSkipped++;
            console.log(`${index + 1}/${total} act_${businessID} | -> Bỏ qua (trạng thái: ${data.account_status})`);
        }
        
    } catch (e) {
        stats.kichHoatFailed++;
        console.log(`❌ Lỗi xử lý tài khoản ${index + 1}:`, e);
    } finally {
        // Tăng index và cập nhật UI
        const nextIndex = index + 1;
        stats.kichHoatCurrent = nextIndex;
        updateCombinedWebUI();
        
        // Giảm delay để tăng tốc độ
        await new Promise(resolve => setTimeout(resolve, 10));
        
        // Kiểm tra nếu đã dừng trước khi tiếp tục
        if (stats.isRunning) {
            // Gọi đệ quy với nextIndex
            action1(nextIndex, arr, access_token, fb_dtsg2, uid);
        } else {
            console.log('🛑 Đã dừng chương trình kích hoạt');
            stats.kichHoatIsRunning = false;
        }
    }
}

// Thêm hàm xử lý song song cho kích hoạt
async function processKichHoatParallel(accounts, access_token, fb_dtsg2, uid) {
    console.log(`🚀 Bắt đầu xử lý SONG SONG ${accounts.length} tài khoản kích hoạt`);
    
    // Lấy batch size từ cấu hình
    const batchSize = parseInt(document.getElementById('kichHoatBatchSize')?.value) || 50;
    
    // Chia thành các batch nhỏ để tránh quá tải
    const batches = [];
    
    for (let i = 0; i < accounts.length; i += batchSize) {
        batches.push(accounts.slice(i, i + batchSize));
    }
    
    console.log(`📦 Chia thành ${batches.length} batch, mỗi batch ${batchSize} tài khoản`);
    
    for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
        if (!stats.isRunning) {
            console.log('🛑 Đã dừng chương trình kích hoạt');
            break;
        }
        
        const batch = batches[batchIndex];
        console.log(`🔄 Xử lý batch ${batchIndex + 1}/${batches.length} (${batch.length} tài khoản)`);
        
        // Xử lý song song trong batch
        const promises = batch.map((account, index) => {
            const globalIndex = batchIndex * batchSize + index;
            const businessID = account.id.replace("act_", "");
            
            if (account.account_status === 100 || account.account_status === 101) {
                stats.kichHoatProcessing++;
                return action2(businessID, globalIndex, accounts.length, account.name, access_token, fb_dtsg2, uid);
            } else {
                stats.kichHoatSkipped++;
                console.log(`${globalIndex + 1}/${accounts.length} act_${businessID} | -> Bỏ qua (trạng thái: ${account.account_status})`);
                return Promise.resolve();
            }
        });
        
        // Chờ batch hiện tại hoàn thành
        await Promise.all(promises);
        
        // Cập nhật UI sau mỗi batch
        updateCombinedWebUI();
        
        // Delay nhỏ giữa các batch
        if (batchIndex < batches.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 50));
        }
    }
    
    console.log(`✅ Hoàn thành xử lý song song! Thành công: ${stats.kichHoatSuccess}/${stats.kichHoatTotal}`);
}

async function startKichHoatProcess() {
    const requiredData = getRequiredData();
    if (!requiredData) {
        console.error('Không thể lấy dữ liệu cần thiết');
        return 0;
    }
    
    const { access_token, fb_dtsg2, uid } = requiredData;
    
    stats.kichHoatStartTime = new Date();
    stats.kichHoatIsRunning = true;
    stats.currentPhase = 'kichhoat';
    
    updatePhaseIndicator('kichhoat', 'Đang kích hoạt lại các tài khoản đã tách');
    
    console.log('🔓 BẮT ĐẦU KÍCH HOẠT TÀI KHOẢN QUẢNG CÁO (SONG SONG)');
    console.log(`⏰ Thời gian bắt đầu: ${stats.kichHoatStartTime.toLocaleString()}`);
    console.log('=====================================\n');
    
    try {
        console.log('📡 Đang lấy danh sách tài khoản quảng cáo...');
        const json = await getBusinesses2(access_token);
        const arr = { data: json };
        
        console.log(`📊 Tìm thấy ${arr.data.adaccounts.data.length} tài khoản quảng cáo`);
        
        // Kiểm tra nếu đã dừng
        if (!stats.isRunning) {
            console.log('🛑 Đã dừng chương trình');
            stats.kichHoatIsRunning = false;
            return 0;
        }
        
        console.log('🚀 Bắt đầu xử lý song song...');
        
        // Sử dụng xử lý song song thay vì tuần tự
        await processKichHoatParallel(arr.data.adaccounts.data, access_token, fb_dtsg2, uid);
        
        console.log(`✅ Hoàn thành kích hoạt! Tổng kết: ${stats.kichHoatSuccess}/${stats.kichHoatTotal} thành công`);
        return stats.kichHoatSuccess;
    } catch (error) {
        console.error('❌ Lỗi trong quá trình kích hoạt:', error);
        stats.kichHoatIsRunning = false;
        return 0;
    }
} 

// ==================== HÀM CHÍNH ĐIỀU PHỐI ====================

async function mainCombinedProcess() {
    // Lấy cấu hình từ giao diện
    loadConfigFromUI();
    
    stats.isRunning = true;
    
    // Cập nhật trạng thái nút
    updateButtonStates();
    
    console.log('🚀 AD TOOL PRO - BẮT ĐẦU QUÁ TRÌNH TỔNG HỢP');
    console.log('=====================================');
    
    try {
        // Bước 1: Tách tài khoản
        console.log('\n🔧 BƯỚC 1: TÁCH TÀI KHOẢN QUẢNG CÁO');
        updatePhaseIndicator('tach', 'Đang tách tài khoản quảng cáo từ Business Manager');
        
        const tachResult = await startTachProcess();
        console.log(`✅ Hoàn thành tách: ${tachResult} tài khoản thành công`);
        
        // Kiểm tra nếu đã dừng
        if (!stats.isRunning) {
            console.log('🛑 Đã dừng chương trình');
            updatePhaseIndicator('idle', 'Đã dừng chương trình');
            updateButtonStates();
            return;
        }
        
        // Kiểm tra điều kiện chuyển sang kích hoạt
        let shouldActivate = false;
        let activationReason = '';
        
        if (stats.config.enableKichHoat) {
            if (stats.tachSuccessCount >= stats.config.targetSuccess) {
                shouldActivate = true;
                activationReason = 'Đã đạt đủ số tài khoản thành công';
            } else if (stats.tachFailureCount >= stats.config.failureThresholdToKichHoat) {
                shouldActivate = true;
                activationReason = 'Số lần thất bại vượt quá ngưỡng';
            }
        }
        
        if (shouldActivate) {
            // Hiển thị timer đếm ngược
            console.log(`\n⏰ ${activationReason}. Chờ ${stats.config.delayBeforeKichHoat} giây trước khi kích hoạt...`);
            updatePhaseIndicator('tach', `${activationReason}. Chờ ${stats.config.delayBeforeKichHoat} giây trước khi kích hoạt...`);
            showTimer(stats.config.delayBeforeKichHoat);
            
            // Đợi theo cấu hình
            await new Promise(resolve => setTimeout(resolve, stats.config.delayBeforeKichHoat * 1000));
            
            // Kiểm tra nếu đã dừng
            if (!stats.isRunning) {
                console.log('🛑 Đã dừng chương trình');
                updatePhaseIndicator('idle', 'Đã dừng chương trình');
                updateButtonStates();
                return;
            }
            
            // Bước 2: Kích hoạt tài khoản
            console.log('\n🔓 BƯỚC 2: KÍCH HOẠT TÀI KHOẢN QUẢNG CÁO');
            updatePhaseIndicator('kichhoat', 'Đang kích hoạt lại các tài khoản đã tách');
            
            const kichHoatResult = await startKichHoatProcess();
            console.log(`✅ Hoàn thành kích hoạt: ${kichHoatResult} tài khoản thành công`);
        }
        
        // Hoàn thành toàn bộ quá trình
        console.log('\ HOÀN THÀNH TOÀN BỘ QUÁ TRÌNH!');
        updatePhaseIndicator('completed', 'Tất cả quá trình đã hoàn tất thành công');
        
        // Hiển thị báo cáo tổng hợp
        showCompletionCombinedWebUI();
        
        // Thống kê cuối cùng
        const totalSuccess = stats.tachSuccessCount + stats.kichHoatSuccess;
        const totalTime = Math.round((new Date() - stats.tachStartTime) / 1000);
        
        console.log('\n📊 THỐNG KÊ TỔNG HỢP:');
        console.log(`🔧 Tách tài khoản: ${stats.tachSuccessCount}/${stats.config.targetSuccess} thành công`);
        console.log(`🔓 Kích hoạt tài khoản: ${stats.kichHoatSuccess}/${stats.kichHoatTotal} thành công`);
        console.log(`🎯 Tổng cộng: ${totalSuccess} tài khoản hoàn tất`);
        console.log(`⏱️ Tổng thời gian: ${totalTime} giây`);
        console.log('\nHASoftware - Ads Solution - Auto Version');
        
    } catch (error) {
        console.error('❌ Lỗi trong quá trình tổng hợp:', error);
        updatePhaseIndicator('completed', 'Có lỗi xảy ra trong quá trình xử lý');
    } finally {
        stats.isRunning = false;
        updateButtonStates();
    }
}

// Hàm khởi chạy chương trình
function startAdToolPro() {
    if (stats.isRunning) {
        console.log('⚠️ Chương trình đang chạy. Vui lòng đợi hoàn thành.');
        return;
    }
    
    // Tạo giao diện web nếu chưa có
    if (!document.querySelector('.adtool-pro-modal')) {
        createCombinedWebUI();
        console.log('🎨 Đã tạo giao diện AdTool Pro');
    } else {
        console.log('ℹ️ Giao diện AdTool Pro đã tồn tại');
    }
    
    // Reset thống kê
    stats = {
        // Thống kê tách tài khoản
        tachTotalProcessed: 0,
        tachSuccessCount: 0,
        tachFailureCount: 0,
        tachTargetSuccess: 600,
        tachStartTime: null,
        tachActiveRequests: 0,
        tachMaxConcurrentRequests: 200,
        tachIsRunning: false,
        tachCurrentAccounts: [],
        
        // Thống kê kích hoạt tài khoản
        kichHoatTotal: 0,
        kichHoatSuccess: 0,
        kichHoatFailed: 0,
        kichHoatSkipped: 0,
        kichHoatProcessing: 0,
        kichHoatCurrent: 0,
        kichHoatStartTime: null,
        kichHoatIsRunning: false,
        
        // Trạng thái tổng thể
        currentPhase: 'idle',
        isRunning: false,
        failureThreshold: 500,
        
        // Cấu hình mới
        config: {
            enableKichHoat: true,
            failureThresholdToKichHoat: 500,
            delayBeforeKichHoat: 300,
            targetSuccess: 600,
            enableDelayBetweenAccounts: false,
            delayBetweenAccounts: 1,
            kichHoatBatchSize: 50
        }
    };
    
    // Khởi chạy quá trình tổng hợp
    mainCombinedProcess();
}

// Hàm dừng chương trình
function stopAdToolPro() {
    stats.isRunning = false;
    stats.tachIsRunning = false;
    stats.kichHoatIsRunning = false;
    console.log('🛑 Đã dừng chương trình AD TOOL PRO');
    updateButtonStates();
}

// Hàm cập nhật cài đặt
function updateSettings(newSettings) {
    if (newSettings.tachTargetSuccess) {
        stats.tachTargetSuccess = newSettings.tachTargetSuccess;
    }
    if (newSettings.maxConcurrentRequests) {
        stats.tachMaxConcurrentRequests = newSettings.maxConcurrentRequests;
    }
    if (newSettings.failureThreshold) {
        stats.failureThreshold = newSettings.failureThreshold;
    }
    console.log('⚙️ Đã cập nhật cài đặt:', newSettings);
}

// Hàm load cấu hình từ giao diện
function loadConfigFromUI() {
    try {
        const tachTargetSuccess = parseInt(document.getElementById('tachTargetSuccess').value) || 600;
        const maxConcurrentRequests = parseInt(document.getElementById('maxConcurrentRequests').value) || 200;
        const failureThreshold = parseInt(document.getElementById('failureThreshold').value) || 500;
        const enableKichHoat = document.getElementById('enableKichHoat').checked;
        const delayBeforeKichHoat = parseInt(document.getElementById('delayBeforeKichHoat').value) || 300;
        const enableDelayBetweenAccounts = document.getElementById('enableDelayBetweenAccounts').checked;
        const delayBetweenAccounts = parseInt(document.getElementById('delayBetweenAccounts').value) || 1;
        const kichHoatBatchSize = parseInt(document.getElementById('kichHoatBatchSize').value) || 50;
        
        // Cập nhật cấu hình
        stats.config.targetSuccess = tachTargetSuccess;
        stats.tachMaxConcurrentRequests = maxConcurrentRequests;
        stats.config.failureThresholdToKichHoat = failureThreshold;
        stats.config.enableKichHoat = enableKichHoat;
        stats.config.delayBeforeKichHoat = delayBeforeKichHoat;
        stats.config.enableDelayBetweenAccounts = enableDelayBetweenAccounts;
        stats.config.delayBetweenAccounts = delayBetweenAccounts;
        stats.config.kichHoatBatchSize = kichHoatBatchSize;
        
        console.log('⚙️ Đã load cấu hình từ giao diện:', {
            ...stats.config,
            tachMaxConcurrentRequests: stats.tachMaxConcurrentRequests
        });
    } catch (error) {
        console.error('❌ Lỗi load cấu hình:', error);
    }
}

// Hàm cập nhật trạng thái nút
function updateButtonStates() {
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');
    const closeButton = document.getElementById('closeButton');
    
    if (startButton && stopButton && closeButton) {
        if (stats.isRunning) {
            startButton.disabled = true;
            stopButton.disabled = false;
            closeButton.disabled = true; // Disable close button when running
        } else {
            startButton.disabled = false;
            stopButton.disabled = true;
            closeButton.disabled = false; // Enable close button when idle
        }
    }
}

// Export các hàm để sử dụng
window.AdToolPro = {
    start: startAdToolPro,
    stop: stopAdToolPro,
    updateSettings: updateSettings,
    stats: stats
};

// Tự động khởi chạy khi load script
console.log('🚀 AD TOOL PRO đã sẵn sàng!');
console.log('Sử dụng: AdToolPro.start() để bắt đầu');
console.log('Sử dụng: AdToolPro.stop() để dừng');
console.log('Sử dụng: AdToolPro.updateSettings({...}) để cập nhật cài đặt');

// Tạo giao diện và hiển thị ngay khi load script
if (!document.querySelector('.adtool-pro-modal')) {
    createCombinedWebUI();
    console.log('🎨 Đã tạo giao diện AdTool Pro');
} else {
    console.log('ℹ️ Giao diện AdTool Pro đã tồn tại');
} 